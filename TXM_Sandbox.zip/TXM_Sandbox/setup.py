#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jul 16 22:20:14 2020

@author: xiao
"""

from setuptools import setup

setup(name='TXM_Sandbox',
      version='0.1',
      description='Integrated Spectro-Imaging Analysis Toolbox',
      url='',
      author='Xianghui Xiao',
      author_email='xianghuix@gmail.com',
      license='MIT',
      packages=['TXM_Sandbox'],
      zip_safe=False)