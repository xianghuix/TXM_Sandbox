This folder will contain temporary data files generated in analysis.
