#!/usr/bin/env python3
# -*- coding: utf-8 -*-

def user_tomo_reader(*args, **kwargs):
    pass

def user_xanes2D_reader(*args, **kwargs):
    pass

def user_xanes3D_reader(*args, **kwargs):
    pass

def user_tomo_info_reader(*args, **kwargs):
    pass